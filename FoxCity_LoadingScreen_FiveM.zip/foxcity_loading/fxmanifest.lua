fx_version 'cerulean'
game 'gta5'

author 'Fox City RP'
description 'Loading screen completa com música, volume, dicas e barra de progresso'
version '1.0.0'

loadscreen 'index.html'
loadscreen_cursor 'yes'
loadscreen_manual_shutdown 'yes'

files {
    'index.html',
    'style.css',
    'script.js',
    'assets/music/musica.mp3',
    'assets/images/logo.svg'
}
