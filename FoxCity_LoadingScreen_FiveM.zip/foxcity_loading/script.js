const music = document.getElementById('backgroundMusic');
const button = document.getElementById('musicButton');
const volume = document.getElementById('volume');
const statusText = document.getElementById('musicStatus');
const progressBar = document.getElementById('progressBar');
const percentage = document.getElementById('percentage');
const loadingText = document.getElementById('loadingText');
const tipText = document.getElementById('tipText');

music.volume = Number(volume.value);

const tips = [
    'Respeite as regras e valorize o RP de todos.',
    'Use o Discord oficial para acompanhar avisos e novidades.',
    'Crie uma história única para o seu personagem.',
    'Evite quebrar o personagem durante as situações de RP.',
    'Valorize sua vida e a dos outros jogadores.',
    'Denúncias devem ser feitas com provas pela equipe responsável.'
];

let tipIndex = 0;
setInterval(() => {
    tipIndex = (tipIndex + 1) % tips.length;
    tipText.style.opacity = '0';
    setTimeout(() => {
        tipText.textContent = tips[tipIndex];
        tipText.style.opacity = '1';
    }, 250);
}, 5500);

button.addEventListener('click', async () => {
    if (music.paused) {
        try { await music.play(); } catch (_) {}
        button.textContent = '❚❚';
        statusText.textContent = 'TOCANDO AGORA';
    } else {
        music.pause();
        button.textContent = '▶';
        statusText.textContent = 'MÚSICA PAUSADA';
    }
});

volume.addEventListener('input', () => {
    music.volume = Number(volume.value);
});

window.addEventListener('click', () => {
    if (music.paused) {
        music.play().catch(() => {});
    }
}, { once: true });

const particles = document.getElementById('particles');
for (let i = 0; i < 40; i++) {
    const p = document.createElement('span');
    p.className = 'particle';
    p.style.left = `${Math.random() * 100}%`;
    p.style.animationDuration = `${8 + Math.random() * 12}s`;
    p.style.animationDelay = `${Math.random() * -15}s`;
    p.style.opacity = `${0.1 + Math.random() * 0.45}`;
    particles.appendChild(p);
}

let simulatedProgress = 0;
const fallbackProgress = setInterval(() => {
    if (simulatedProgress < 92) {
        simulatedProgress += Math.random() * 1.6;
        updateProgress(simulatedProgress);
    }
}, 450);

function updateProgress(value) {
    const safe = Math.max(0, Math.min(100, Math.round(value)));
    progressBar.style.width = `${safe}%`;
    percentage.textContent = `${safe}%`;

    if (safe < 30) loadingText.textContent = 'Preparando os arquivos da cidade...';
    else if (safe < 65) loadingText.textContent = 'Carregando mapas e veículos...';
    else if (safe < 95) loadingText.textContent = 'Sincronizando seu personagem...';
    else loadingText.textContent = 'Bem-vindo à Fox City RP!';
}

window.addEventListener('message', (event) => {
    const data = event.data;

    if (data.eventName === 'loadProgress' && typeof data.loadFraction === 'number') {
        clearInterval(fallbackProgress);
        updateProgress(data.loadFraction * 100);
    }

    if (data.action === 'closeLoading') {
        updateProgress(100);
        setTimeout(() => {
            document.body.style.opacity = '0';
            fetch(`https://${GetParentResourceName()}/shutdown`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json; charset=UTF-8' },
                body: JSON.stringify({})
            }).catch(() => {});
        }, 900);
    }
});
